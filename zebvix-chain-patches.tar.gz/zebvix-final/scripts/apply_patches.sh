#!/usr/bin/env bash
# ==========================================================================
# ZEBVIX CHAIN — Master Patch Script
# Applies all Zebvix patches to a Sui mainnet-v1.69.2 clone
#
# Usage:
#   1. Clone Sui:  git clone --branch mainnet-v1.69.2 https://github.com/MystenLabs/sui ~/zebvix-node
#   2. Run:        bash apply_patches.sh ~/zebvix-node
# ==========================================================================
set -euo pipefail

BLUE='\033[1;34m'; GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'
info()  { echo -e "${BLUE}[ZBX]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}  $*"; }
fail()  { echo -e "${RED}[ERR]${NC} $*"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_ROOT="$(dirname "$SCRIPT_DIR")"
TARGET="${1:-$HOME/zebvix-node}"

# ── Validate target ──────────────────────────────────────────────────────
[[ -d "$TARGET" ]] || fail "Target directory not found: $TARGET"
[[ -f "$TARGET/Cargo.toml" ]] || fail "Not a Sui repo: $TARGET/Cargo.toml missing"

info "Zebvix patch target: $TARGET"
info "Patch source:        $PATCH_ROOT"

# ── Step 1: Apply patched Rust files ───────────────────────────────────────
info "Step 1/4 — Applying patched Rust files..."

# gas_coin.rs — tokenomics constants (ZBX: 150M max, 2M genesis, halvings)
GCOIN_DEST="$TARGET/crates/sui-types/src/gas_coin.rs"
GCOIN_SRC="$PATCH_ROOT/crates/sui-types/src/gas_coin.rs"
[[ -f "$GCOIN_SRC" ]] || fail "Patch file missing: $GCOIN_SRC"
cp "$GCOIN_SRC" "$GCOIN_DEST"
ok "gas_coin.rs → ZBX tokenomics constants applied"

# base_types.rs — 20-byte EVM-style address
BTYPES_DEST="$TARGET/crates/sui-types/src/base_types.rs"
BTYPES_SRC="$PATCH_ROOT/crates/sui-types/src/base_types.rs"
[[ -f "$BTYPES_SRC" ]] || fail "Patch file missing: $BTYPES_SRC"
cp "$BTYPES_SRC" "$BTYPES_DEST"
ok "base_types.rs → 20-byte EVM address (last 20 of Blake2b256)"

# Cargo.toml — rename binary to zebvix-node
CARGO_DEST="$TARGET/crates/sui-node/Cargo.toml"
CARGO_SRC="$PATCH_ROOT/crates/sui-node/Cargo.toml"
[[ -f "$CARGO_SRC" ]] || fail "Patch file missing: $CARGO_SRC"
cp "$CARGO_SRC" "$CARGO_DEST"
ok "Cargo.toml → binary renamed to zebvix-node"

# ── Step 2: Install Move modules ─────────────────────────────────────────
info "Step 2/4 — Deploying Zebvix Move modules..."

MOVE_DEST="$TARGET/crates/sui-framework/packages/zebvix"
MOVE_SRC="$PATCH_ROOT/crates/sui-framework/packages/zebvix"
[[ -d "$MOVE_SRC" ]] || fail "Move package missing: $MOVE_SRC"
cp -r "$MOVE_SRC" "$MOVE_DEST"
ok "Zebvix Move package copied (6 modules)"

# ── Step 3: Chain ID & genesis config ────────────────────────────────────
info "Step 3/4 — Applying chain configuration..."

CONF_SRC="$PATCH_ROOT/config"
if [[ -d "$CONF_SRC" ]]; then
  # Apply config/genesis.yaml if exists
  for yaml in "$CONF_SRC"/*.yaml "$CONF_SRC"/*.json; do
    [[ -f "$yaml" ]] || continue
    fname=$(basename "$yaml")
    cp "$yaml" "$TARGET/$fname" && ok "  config/$fname applied"
  done
fi

# Patch chain name in Cargo workspace if present
if grep -q '"sui-mainnet-1"\|"mainnet"' "$TARGET/crates/sui-protocol-config/src/lib.rs" 2>/dev/null; then
  sed -i 's/"sui-mainnet-1"/"zebvix-mainnet-1"/g' \
    "$TARGET/crates/sui-protocol-config/src/lib.rs" && \
    ok "protocol-config chain ID → zebvix-mainnet-1"
fi

# ── Step 4: Rename sui → zebvix in key Rust strings ──────────────────────
info "Step 4/4 — Renaming SUI → ZBX in genesis strings..."

FILES_TO_RENAME=(
  "$TARGET/crates/sui-genesis-builder/src/lib.rs"
  "$TARGET/crates/sui-types/src/sui_system_state/mod.rs"
)
for f in "${FILES_TO_RENAME[@]}"; do
  [[ -f "$f" ]] || continue
  sed -i \
    -e 's/MIST_PER_SUI/MIST_PER_ZBX/g' \
    -e 's/TOTAL_SUPPLY_SUI/TOTAL_SUPPLY_ZBX/g' \
    "$f" && ok "  renamed MIST_PER_SUI → MIST_PER_ZBX in $(basename $f)"
done

echo ""
echo -e "${GREEN}============================================================"
echo " Zebvix patches applied successfully!"
echo ""
echo " Next: Build the node"
echo "   cd $TARGET"
echo "   cargo build --release --bin zebvix-node"
echo "   # Binary: target/release/zebvix-node"
echo "============================================================${NC}"
