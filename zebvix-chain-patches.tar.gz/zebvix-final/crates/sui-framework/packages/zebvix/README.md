# Zebvix Move Packages

  Core on-chain modules for **Zebvix Chain** (zebvix-mainnet-1) — ZBX token.

  ## Modules

  | Module | Description |
  |--------|-------------|
  | `zbx_token` | ZBX native token: 150M max, 2M genesis, halving |
  | `pay_id` | UPI-style Pay ID (rahul@zbx) — unique per address |
  | `staking_pool` | Validator (120% APR) + Delegator (80% APR) staking |
  | `master_pool` | Decentralized AMM base pool (no admin, anti-rug) |
  | `sub_pool` | Permissionless token-pair pools (x*y=k) |
  | `founder_admin` | MultiSig 4/6 admin cap — new features only |

  ## Deploy

  ```bash
  sui move publish \
    --gas-budget 200000000 \
    --json
  ```
  