// Copyright (c) Mysten Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use move_core_types::{
    annotated_value::MoveStructLayout,
    ident_str,
    identifier::IdentStr,
    language_storage::{StructTag, TypeTag},
};
use serde::{Deserialize, Serialize};
use std::convert::{TryFrom, TryInto};
use std::fmt::{Display, Formatter};

use crate::{
    SUI_FRAMEWORK_ADDRESS,
    balance::Balance,
    base_types::{ObjectID, SequenceNumber},
    coin::Coin,
    error::ExecutionError,
    execution_status::ExecutionErrorKind,
    object::{Data, MoveObject, Object},
};

/// ZBX: Mist per ZBX token
pub const MIST_PER_ZBX: u64 = 1_000_000_000;
/// Alias kept for Sui internal compatibility
pub const MIST_PER_SUI: u64 = MIST_PER_ZBX;

/// ZBX max supply: 150 million ZBX
pub const TOTAL_SUPPLY_ZBX: u64 = 150_000_000;
/// Alias for Sui internal compatibility
pub const TOTAL_SUPPLY_SUI: u64 = TOTAL_SUPPLY_ZBX;

// Note: cannot use checked arithmetic here since `const unwrap` is still unstable.
/// Total supply denominated in Mist
pub const TOTAL_SUPPLY_MIST: u64 = TOTAL_SUPPLY_ZBX * MIST_PER_ZBX;


  // ================================================================
  // ZEBVIX CHAIN CONSTANTS  (zebvix-mainnet-1)
  // ================================================================

  pub const GENESIS_SUPPLY_ZBX:          u64 = 2_000_000;
  pub const GENESIS_SUPPLY_MIST:         u64 = GENESIS_SUPPLY_ZBX * MIST_PER_ZBX;

  pub const FIRST_HALVING_ZBX:           u64 =  50_000_000;
  pub const SECOND_HALVING_ZBX:          u64 = 100_000_000;
  pub const INITIAL_BLOCK_REWARD_MIST:   u64 = 100_000_000; // 0.1 ZBX

  pub const GAS_VALIDATOR_BPS:           u64 = 7200; // 72 %
  pub const GAS_TREASURY_BPS:            u64 = 1800; // 18 %
  pub const GAS_BURN_BPS:                u64 = 1000; // 10 %

  pub const MAX_BURN_SUPPLY_ZBX:         u64 = 75_000_000;
  pub const MAX_BURN_SUPPLY_MIST:        u64 = MAX_BURN_SUPPLY_ZBX * MIST_PER_ZBX;

  pub const MAX_VALIDATORS:              u64 = 41;
  pub const MIN_VALIDATOR_STAKE_ZBX:     u64 = 10_000;
  pub const MIN_VALIDATOR_STAKE_MIST:    u64 = MIN_VALIDATOR_STAKE_ZBX * MIST_PER_ZBX;
  pub const MAX_STAKE_PER_VALIDATOR_ZBX: u64 = 5_000_000;
  pub const VALIDATOR_STAKING_APR:       u64 = 120;
  pub const DELEGATOR_APR:               u64 = 80;
  pub const VALIDATOR_DELEGATION_BONUS:  u64 = 40;
  pub const NODE_DAILY_REWARD_MIST:      u64 = 5 * MIST_PER_ZBX; // 5 ZBX/day

  pub const CHAIN_ID:       &str = "zebvix-mainnet-1";
  pub const TOKEN_SYMBOL:   &str = "ZBX";
  pub const TOKEN_DECIMALS: u8   = 9;

  /// Halving divisor based on total minted supply
  pub fn halving_divisor(total_minted_zbx: u64) -> u64 {
      if total_minted_zbx < FIRST_HALVING_ZBX       { 1 }
      else if total_minted_zbx < SECOND_HALVING_ZBX { 2 }
      else                                            { 4 }
  }

  /// Current block reward (MIST) accounting for halvings
  pub fn current_block_reward_mist(total_minted_zbx: u64) -> u64 {
      INITIAL_BLOCK_REWARD_MIST / halving_divisor(total_minted_zbx)
  }

  /// Split gas fee: returns (validator_share, treasury_share, burn_share)
  /// If burn cap is exceeded, burn share is redirected to validators.
  pub fn split_gas_fee(fee: u64, total_burned: u64) -> (u64, u64, u64) {
      let v = fee * GAS_VALIDATOR_BPS / 10_000;
      let t = fee * GAS_TREASURY_BPS  / 10_000;
      let b = fee * GAS_BURN_BPS      / 10_000;
      if total_burned < MAX_BURN_SUPPLY_MIST { (v, t, b) } else { (v + b, t, 0) }
  }

  /// True if the active validator count is at the 41-slot cap
  pub fn is_validator_cap_reached(active: u64) -> bool { active >= MAX_VALIDATORS }

  // ================================================================

  pub const GAS_MODULE_NAME: &IdentStr = ident_str!("sui");
pub const GAS_STRUCT_NAME: &IdentStr = ident_str!("SUI");

pub use checked::*;

#[sui_macros::with_checked_arithmetic]
mod checked {
    use super::*;

    pub struct GAS {}
    impl GAS {
        pub fn type_() -> StructTag {
            StructTag {
                address: SUI_FRAMEWORK_ADDRESS,
                name: GAS_STRUCT_NAME.to_owned(),
                module: GAS_MODULE_NAME.to_owned(),
                type_params: Vec::new(),
            }
        }

        pub fn type_tag() -> TypeTag {
            TypeTag::Struct(Box::new(Self::type_()))
        }

        pub fn is_gas(other: &StructTag) -> bool {
            &Self::type_() == other
        }

        pub fn is_gas_type(other: &TypeTag) -> bool {
            match other {
                TypeTag::Struct(s) => Self::is_gas(s),
                _ => false,
            }
        }
    }

    /// Rust version of the Move sui::coin::Coin<Sui::sui::SUI> type
    #[derive(Clone, Debug, Serialize, Deserialize)]
    pub struct GasCoin(pub Coin);

    impl GasCoin {
        pub fn new(id: ObjectID, value: u64) -> Self {
            Self(Coin::new(id, value))
        }

        pub fn value(&self) -> u64 {
            self.0.value()
        }

        pub fn type_() -> StructTag {
            Coin::type_(TypeTag::Struct(Box::new(GAS::type_())))
        }

        /// Return `true` if `s` is the type of a gas coin (i.e., 0x2::coin::Coin<0x2::sui::SUI>)
        pub fn is_gas_coin(s: &StructTag) -> bool {
            Coin::is_coin(s) && s.type_params.len() == 1 && GAS::is_gas_type(&s.type_params[0])
        }

        /// Return `true` if `s` is the type of a gas balance (i.e., 0x2::balance::Balance<0x2::sui::SUI>)
        pub fn is_gas_balance(s: &StructTag) -> bool {
            Balance::is_balance(s)
                && s.type_params.len() == 1
                && GAS::is_gas_type(&s.type_params[0])
        }

        pub fn is_gas_balance_type(type_param: &TypeTag) -> bool {
            if let TypeTag::Struct(s) = type_param {
                Self::is_gas_balance(s)
            } else {
                false
            }
        }

        pub fn id(&self) -> &ObjectID {
            self.0.id()
        }

        pub fn to_bcs_bytes(&self) -> Vec<u8> {
            bcs::to_bytes(&self).unwrap()
        }

        pub fn to_object(&self, version: SequenceNumber) -> MoveObject {
            MoveObject::new_gas_coin(version, *self.id(), self.value())
        }

        pub fn layout() -> MoveStructLayout {
            Coin::layout(TypeTag::Struct(Box::new(GAS::type_())))
        }

        pub fn new_for_testing(value: u64) -> Self {
            Self::new(ObjectID::random(), value)
        }

        pub fn new_for_testing_with_id(id: ObjectID, value: u64) -> Self {
            Self::new(id, value)
        }
    }

    impl TryFrom<&MoveObject> for GasCoin {
        type Error = ExecutionError;

        fn try_from(value: &MoveObject) -> Result<GasCoin, ExecutionError> {
            if !value.type_().is_gas_coin() {
                return Err(ExecutionError::new_with_source(
                    ExecutionErrorKind::InvalidGasObject,
                    format!("Gas object type is not a gas coin: {}", value.type_()),
                ));
            }
            let gas_coin: GasCoin = bcs::from_bytes(value.contents()).map_err(|err| {
                ExecutionError::new_with_source(
                    ExecutionErrorKind::InvalidGasObject,
                    format!("Unable to deserialize gas object: {:?}", err),
                )
            })?;
            Ok(gas_coin)
        }
    }

    impl TryFrom<&Object> for GasCoin {
        type Error = ExecutionError;

        fn try_from(value: &Object) -> Result<GasCoin, ExecutionError> {
            match &value.data {
                Data::Move(obj) => obj.try_into(),
                Data::Package(_) => Err(ExecutionError::new_with_source(
                    ExecutionErrorKind::InvalidGasObject,
                    format!("Gas object type is not a gas coin: {:?}", value),
                )),
            }
        }
    }

    impl Display for GasCoin {
        fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
            write!(f, "Coin {{ id: {}, value: {} }}", self.id(), self.value())
        }
    }
}
