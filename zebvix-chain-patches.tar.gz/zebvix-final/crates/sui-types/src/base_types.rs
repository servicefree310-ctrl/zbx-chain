// Copyright (c) 2021, Facebook, Inc. and its affiliates
// Copyright (c) Mysten Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use crate::MOVE_STDLIB_ADDRESS;
use crate::MoveTypeTagTrait;
use crate::MoveTypeTagTraitGeneric;
use crate::SUI_CLOCK_OBJECT_ID;
use crate::SUI_FRAMEWORK_ADDRESS;
use crate::SUI_SYSTEM_ADDRESS;
use crate::accumulator_root::accumulator_value_balance_type_maybe;
use crate::balance::Balance;
use crate::coin::COIN_MODULE_NAME;
use crate::coin::COIN_STRUCT_NAME;
use crate::coin::Coin;
use crate::coin::CoinMetadata;
use crate::coin::TreasuryCap;
use crate::coin_registry::Currency;
pub use crate::committee::EpochId;
use crate::crypto::{
    AuthorityPublicKeyBytes, DefaultHash, PublicKey, SignatureScheme, SuiPublicKey, SuiSignature,
};
pub use crate::digests::{ObjectDigest, TransactionDigest, TransactionEffectsDigest};
use crate::dynamic_field::DynamicFieldInfo;
use crate::dynamic_field::DynamicFieldType;
use crate::dynamic_field::{DYNAMIC_FIELD_FIELD_STRUCT_NAME, DYNAMIC_FIELD_MODULE_NAME};
use crate::effects::TransactionEffects;
use crate::effects::TransactionEffectsAPI;
use crate::epoch_data::EpochData;
use crate::error::SuiError;
use crate::error::SuiErrorKind;
use crate::error::{ExecutionError, SuiResult};
use crate::execution_status::ExecutionErrorKind;
use crate::gas_coin::GAS;
use crate::gas_coin::GasCoin;
use crate::governance::STAKED_SUI_STRUCT_NAME;
use crate::governance::STAKING_POOL_MODULE_NAME;
use crate::governance::StakedSui;
use crate::id::RESOLVED_SUI_ID;
use crate::messages_checkpoint::CheckpointTimestamp;
use crate::multisig::MultiSigPublicKey;
use crate::object::{Object, Owner};
use crate::parse_sui_struct_tag;
use crate::signature::GenericSignature;
use crate::sui_serde::Readable;
use crate::sui_serde::to_custom_deser_error;
use crate::sui_serde::to_sui_struct_tag_string;
use crate::transaction::Transaction;
use crate::transaction::VerifiedTransaction;
use crate::zk_login_authenticator::ZkLoginAuthenticator;
use anyhow::anyhow;
use fastcrypto::encoding::decode_bytes_hex;
use fastcrypto::encoding::{Encoding, Hex};
use fastcrypto::hash::HashFunction;
use fastcrypto::traits::AllowedRng;
use fastcrypto_zkp::bn254::zk_login::ZkLoginInputs;
use move_binary_format::CompiledModule;
use move_binary_format::file_format::SignatureToken;
use move_bytecode_utils::resolve_struct;
use move_core_types::account_address::AccountAddress;
use move_core_types::annotated_value as A;
use move_core_types::ident_str;
use move_core_types::identifier::IdentStr;
use move_core_types::language_storage::ModuleId;
use move_core_types::language_storage::StructTag;
use move_core_types::language_storage::TypeTag;
use rand::Rng;
use schemars::JsonSchema;
use serde::Deserializer;
use serde::Serializer;
use serde::ser::Error;
use serde::ser::SerializeSeq;
use serde::{Deserialize, Serialize};
use serde_with::DeserializeAs;
use serde_with::SerializeAs;
use serde_with::serde_as;
use shared_crypto::intent::HashingIntentScope;
use std::borrow::Cow;
use std::cmp::max;
use std::convert::{TryFrom, TryInto};
use std::fmt;
use std::str::FromStr;
use sui_protocol_config::ProtocolConfig;

#[cfg(test)]
#[path = "unit_tests/base_types_tests.rs"]
mod base_types_tests;

#[cfg(test)]
#[path = "unit_tests/accumulator_types_tests.rs"]
mod accumulator_types_tests;

#[derive(
    Eq,
    PartialEq,
    Ord,
    PartialOrd,
    Copy,
    Clone,
    Hash,
    Default,
    Debug,
    Serialize,
    Deserialize,
    JsonSchema,
)]
#[cfg_attr(feature = "fuzzing", derive(proptest_derive::Arbitrary))]
pub struct SequenceNumber(u64);

impl SequenceNumber {
    pub fn one_before(&self) -> Option<SequenceNumber> {
        if self.0 == 0 {
            None
        } else {
            Some(SequenceNumber(self.0 - 1))
        }
    }

    pub fn next(&self) -> SequenceNumber {
        SequenceNumber(self.0 + 1)
    }
}

pub type TxSequenceNumber = u64;

impl fmt::Display for SequenceNumber {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:#x}", self.0)
    }
}

pub type VersionNumber = SequenceNumber;

#[derive(Eq, PartialEq, Ord, PartialOrd, Clone, Hash, Default, Debug, Serialize, Deserialize)]
pub struct UserData(pub Option<[u8; 32]>);

pub type AuthorityName = AuthorityPublicKeyBytes;

pub trait ConciseableName<'a> {
    type ConciseTypeRef: std::fmt::Debug;
    type ConciseType: std::fmt::Debug;

    fn concise(&'a self) -> Self::ConciseTypeRef;
    fn concise_owned(&self) -> Self::ConciseType;
}

#[serde_as]
#[derive(Eq, PartialEq, Clone, Copy, PartialOrd, Ord, Hash, Serialize, Deserialize, JsonSchema)]
pub struct ObjectID(
    #[schemars(with = "Hex")]
    #[serde_as(as = "Readable<HexAccountAddress, _>")]
    AccountAddress,
);

#[serde_as]
#[derive(Debug, Eq, PartialEq, Clone, Copy, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub enum FullObjectID {
    Fastpath(ObjectID),
    Consensus(ConsensusObjectSequenceKey),
}

impl FullObjectID {
    pub fn new(object_id: ObjectID, start_version: Option<SequenceNumber>) -> Self {
        if let Some(start_version) = start_version {
            Self::Consensus((object_id, start_version))
        } else {
            Self::Fastpath(object_id)
        }
    }

    pub fn id(&self) -> ObjectID {
        match &self {
            FullObjectID::Fastpath(object_id) => *object_id,
            FullObjectID::Consensus(consensus_object_sequence_key) => {
                consensus_object_sequence_key.0
            }
        }
    }
}

pub type VersionDigest = (SequenceNumber, ObjectDigest);

pub type ObjectRef = (ObjectID, SequenceNumber, ObjectDigest);

pub fn random_object_ref() -> ObjectRef {
    (
        ObjectID::random(),
        SequenceNumber::new(),
        ObjectDigest::new([0; 32]),
    )
}

pub fn update_object_ref_for_testing(object_ref: ObjectRef) -> ObjectRef {
    (
        object_ref.0,
        object_ref.1.next(),
        ObjectDigest::new([0; 32]),
    )
}

#[derive(Debug, Eq, PartialEq, Clone, Copy, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub struct FullObjectRef(pub FullObjectID, pub SequenceNumber, pub ObjectDigest);

impl FullObjectRef {
    pub fn from_fastpath_ref(object_ref: ObjectRef) -> Self {
        Self(
            FullObjectID::Fastpath(object_ref.0),
            object_ref.1,
            object_ref.2,
        )
    }

    pub fn from_object_ref_and_owner(object_ref: ObjectRef, owner: &Owner) -> Self {
        let full_id = if let Some(start_version) = owner.start_version() {
            FullObjectID::Consensus((object_ref.0, start_version))
        } else {
            FullObjectID::Fastpath(object_ref.0)
        };
        Self(full_id, object_ref.1, object_ref.2)
    }

    pub fn as_object_ref(&self) -> ObjectRef {
        (self.0.id(), self.1, self.2)
    }
}
/// Represents an distinct stream of object versions for a consensus object,
/// based on the object ID and start version.
pub type ConsensusObjectSequenceKey = (ObjectID, SequenceNumber);

/// Wrapper around StructTag with a space-efficient representation for common types like coins
/// The StructTag for a gas coin is 84 bytes, so using 1 byte instead is a win.
/// The inner representation is private to prevent incorrectly constructing an `Other` instead of
/// one of the specialized variants, e.g. `Other(GasCoin::type_())` instead of `GasCoin`
#[derive(Eq, PartialEq, PartialOrd, Ord, Debug, Clone, Deserialize, Serialize, Hash)]
pub struct MoveObjectType(MoveObjectType_);

/// Even though it is declared public, it is the "private", internal representation for
/// `MoveObjectType`
#[derive(Eq, PartialEq, PartialOrd, Ord, Debug, Clone, Deserialize, Serialize, Hash)]
pub enum MoveObjectType_ {
    /// A type that is not `0x2::coin::Coin<T>`
    Other(StructTag),
    /// A SUI coin (i.e., `0x2::coin::Coin<0x2::sui::SUI>`)
    GasCoin,
    /// A record of a staked SUI coin (i.e., `0x3::staking_pool::StakedSui`)
    StakedSui,
    /// A non-SUI coin type (i.e., `0x2::coin::Coin<T> where T != 0x2::sui::SUI`)
    Coin(TypeTag),
    /// A SUI balance accumulator field
    /// (i.e., `0x2::dynamic_field::Field<0x2::accumulator::Key<0x2::balance::Balance<0x2::sui::SUI>>, 0x2::accumulator::U128>`)
    SuiBalanceAccumulatorField,
    /// A non-SUI balance accumulator field
    /// (i.e., `0x2::dynamic_field::Field<0x2::accumulator::Key<0x2::balance::Balance<T>>, 0x2::accumulator::U128>`
    /// where T != 0x2::sui::SUI)
    BalanceAccumulatorField(TypeTag),
    // NOTE: if adding a new type here, and there are existing on-chain objects of that
    // type with Other(_), that is ok, but you must hand-roll PartialEq/Eq/Ord/maybe Hash
    // to make sure the new type and Other(_) are interpreted consistently.
}

impl MoveObjectType {
    pub fn gas_coin() -> Self {
        Self(MoveObjectType_::GasCoin)
    }

    pub fn is_efficient_representation(&self) -> bool {
        !matches!(self.0, MoveObjectType_::Other(_))
    }

    pub fn coin(coin_type: TypeTag) -> Self {
        Self(if GAS::is_gas_type(&coin_type) {
            MoveObjectType_::GasCoin
        } else {
            MoveObjectType_::Coin(coin_type)
        })
    }

    pub fn staked_sui() -> Self {
        Self(MoveObjectType_::StakedSui)
    }

    pub fn address(&self) -> AccountAddress {
        match &self.0 {
            MoveObjectType_::GasCoin | MoveObjectType_::Coin(_) => SUI_FRAMEWORK_ADDRESS,
            MoveObjectType_::StakedSui => SUI_SYSTEM_ADDRESS,
            MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => SUI_FRAMEWORK_ADDRESS,
            MoveObjectType_::Other(s) => s.address,
        }
    }

    pub fn module(&self) -> &IdentStr {
        match &self.0 {
            MoveObjectType_::GasCoin | MoveObjectType_::Coin(_) => COIN_MODULE_NAME,
            MoveObjectType_::StakedSui => STAKING_POOL_MODULE_NAME,
            MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => DYNAMIC_FIELD_MODULE_NAME,
            MoveObjectType_::Other(s) => &s.module,
        }
    }

    pub fn name(&self) -> &IdentStr {
        match &self.0 {
            MoveObjectType_::GasCoin | MoveObjectType_::Coin(_) => COIN_STRUCT_NAME,
            MoveObjectType_::StakedSui => STAKED_SUI_STRUCT_NAME,
            MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => DYNAMIC_FIELD_FIELD_STRUCT_NAME,
            MoveObjectType_::Other(s) => &s.name,
        }
    }

    pub fn type_params(&self) -> Vec<Cow<'_, TypeTag>> {
        match &self.0 {
            MoveObjectType_::GasCoin => vec![Cow::Owned(GAS::type_tag())],
            MoveObjectType_::StakedSui => vec![],
            MoveObjectType_::Coin(inner) => vec![Cow::Borrowed(inner)],
            MoveObjectType_::SuiBalanceAccumulatorField => {
                Self::balance_accumulator_field_type_params(GAS::type_tag())
                    .into_iter()
                    .map(Cow::Owned)
                    .collect()
            }
            MoveObjectType_::BalanceAccumulatorField(inner) => {
                Self::balance_accumulator_field_type_params(inner.clone())
                    .into_iter()
                    .map(Cow::Owned)
                    .collect()
            }
            MoveObjectType_::Other(s) => s.type_params.iter().map(Cow::Borrowed).collect(),
        }
    }

    pub fn into_type_params(self) -> Vec<TypeTag> {
        match self.0 {
            MoveObjectType_::GasCoin => vec![GAS::type_tag()],
            MoveObjectType_::StakedSui => vec![],
            MoveObjectType_::Coin(inner) => vec![inner],
            MoveObjectType_::SuiBalanceAccumulatorField => {
                Self::balance_accumulator_field_type_params(GAS::type_tag())
            }
            MoveObjectType_::BalanceAccumulatorField(inner) => {
                Self::balance_accumulator_field_type_params(inner)
            }
            MoveObjectType_::Other(s) => s.type_params,
        }
    }

    pub fn coin_type_maybe(&self) -> Option<TypeTag> {
        match &self.0 {
            MoveObjectType_::GasCoin => Some(GAS::type_tag()),
            MoveObjectType_::Coin(inner) => Some(inner.clone()),
            MoveObjectType_::StakedSui => None,
            MoveObjectType_::SuiBalanceAccumulatorField => None,
            MoveObjectType_::BalanceAccumulatorField(_) => None,
            MoveObjectType_::Other(_) => None,
        }
    }

    pub fn balance_accumulator_field_type_maybe(&self) -> Option<TypeTag> {
        match &self.0 {
            MoveObjectType_::SuiBalanceAccumulatorField => Some(GAS::type_tag()),
            MoveObjectType_::BalanceAccumulatorField(inner) => Some(inner.clone()),
            _ => None,
        }
    }

    pub fn is_balance_accumulator_field(&self) -> bool {
        matches!(
            self.0,
            MoveObjectType_::SuiBalanceAccumulatorField
                | MoveObjectType_::BalanceAccumulatorField(_)
        )
    }

    pub fn is_sui_balance_accumulator_field(&self) -> bool {
        matches!(self.0, MoveObjectType_::SuiBalanceAccumulatorField)
    }

    pub fn module_id(&self) -> ModuleId {
        ModuleId::new(self.address(), self.module().to_owned())
    }

    pub fn size_for_gas_metering(&self) -> usize {
        // unwraps safe because a `StructTag` cannot fail to serialize
        match &self.0 {
            MoveObjectType_::GasCoin => 1,
            MoveObjectType_::StakedSui => 1,
            MoveObjectType_::Coin(inner) => bcs::serialized_size(inner).unwrap() + 1,
            MoveObjectType_::SuiBalanceAccumulatorField => 1,
            MoveObjectType_::BalanceAccumulatorField(inner) => {
                bcs::serialized_size(inner).unwrap() + 1
            }
            MoveObjectType_::Other(s) => bcs::serialized_size(s).unwrap() + 1,
        }
    }

    /// Return true if `self` is `0x2::coin::Coin<T>` for some T (note: T can be SUI)
    pub fn is_coin(&self) -> bool {
        match &self.0 {
            MoveObjectType_::GasCoin | MoveObjectType_::Coin(_) => true,
            MoveObjectType_::StakedSui
            | MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_)
            | MoveObjectType_::Other(_) => false,
        }
    }

    /// Return true if `self` is 0x2::coin::Coin<0x2::sui::SUI>
    pub fn is_gas_coin(&self) -> bool {
        match &self.0 {
            MoveObjectType_::GasCoin => true,
            MoveObjectType_::StakedSui
            | MoveObjectType_::Coin(_)
            | MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_)
            | MoveObjectType_::Other(_) => false,
        }
    }

    /// Return true if `self` is `0x2::coin::Coin<t>`
    pub fn is_coin_t(&self, t: &TypeTag) -> bool {
        match &self.0 {
            MoveObjectType_::GasCoin => GAS::is_gas_type(t),
            MoveObjectType_::Coin(c) => t == c,
            MoveObjectType_::StakedSui
            | MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_)
            | MoveObjectType_::Other(_) => false,
        }
    }

    pub fn is_staked_sui(&self) -> bool {
        match &self.0 {
            MoveObjectType_::StakedSui => true,
            MoveObjectType_::GasCoin
            | MoveObjectType_::Coin(_)
            | MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_)
            | MoveObjectType_::Other(_) => false,
        }
    }

    pub fn is_coin_metadata(&self) -> bool {
        match &self.0 {
            MoveObjectType_::GasCoin
            | MoveObjectType_::StakedSui
            | MoveObjectType_::Coin(_)
            | MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => false,
            MoveObjectType_::Other(s) => CoinMetadata::is_coin_metadata(s),
        }
    }

    pub fn is_currency(&self) -> bool {
        match &self.0 {
            MoveObjectType_::GasCoin
            | MoveObjectType_::StakedSui
            | MoveObjectType_::Coin(_)
            | MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => false,
            MoveObjectType_::Other(s) => Currency::is_currency(s),
        }
    }

    pub fn is_treasury_cap(&self) -> bool {
        match &self.0 {
            MoveObjectType_::GasCoin
            | MoveObjectType_::StakedSui
            | MoveObjectType_::Coin(_)
            | MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => false,
            MoveObjectType_::Other(s) => TreasuryCap::is_treasury_type(s),
        }
    }

    pub fn is_upgrade_cap(&self) -> bool {
        self.address() == SUI_FRAMEWORK_ADDRESS
            && self.module().as_str() == "package"
            && self.name().as_str() == "UpgradeCap"
    }

    pub fn is_regulated_coin_metadata(&self) -> bool {
        self.address() == SUI_FRAMEWORK_ADDRESS
            && self.module().as_str() == "coin"
            && self.name().as_str() == "RegulatedCoinMetadata"
    }

    pub fn is_coin_deny_cap(&self) -> bool {
        self.address() == SUI_FRAMEWORK_ADDRESS
            && self.module().as_str() == "coin"
            && self.name().as_str() == "DenyCap"
    }

    pub fn is_coin_deny_cap_v2(&self) -> bool {
        self.address() == SUI_FRAMEWORK_ADDRESS
            && self.module().as_str() == "coin"
            && self.name().as_str() == "DenyCapV2"
    }

    pub fn is_dynamic_field(&self) -> bool {
        match &self.0 {
            MoveObjectType_::GasCoin | MoveObjectType_::StakedSui | MoveObjectType_::Coin(_) => {
                false
            }
            MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => true, // These are dynamic fields
            MoveObjectType_::Other(s) => DynamicFieldInfo::is_dynamic_field(s),
        }
    }

    pub fn try_extract_field_name(&self, type_: &DynamicFieldType) -> SuiResult<TypeTag> {
        match &self.0 {
            MoveObjectType_::GasCoin | MoveObjectType_::StakedSui | MoveObjectType_::Coin(_) => {
                Err(SuiErrorKind::ObjectDeserializationError {
                    error: "Error extracting dynamic object name from specialized object type"
                        .to_string(),
                }
                .into())
            }
            MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => {
                let struct_tag: StructTag = self.clone().into();
                DynamicFieldInfo::try_extract_field_name(&struct_tag, type_)
            }
            MoveObjectType_::Other(s) => DynamicFieldInfo::try_extract_field_name(s, type_),
        }
    }

    pub fn try_extract_field_value(&self) -> SuiResult<TypeTag> {
        match &self.0 {
            MoveObjectType_::GasCoin | MoveObjectType_::StakedSui | MoveObjectType_::Coin(_) => {
                Err(SuiErrorKind::ObjectDeserializationError {
                    error: "Error extracting dynamic object value from specialized object type"
                        .to_string(),
                }
                .into())
            }
            MoveObjectType_::SuiBalanceAccumulatorField
            | MoveObjectType_::BalanceAccumulatorField(_) => {
                let struct_tag: StructTag = self.clone().into();
                DynamicFieldInfo::try_extract_field_value(&struct_tag)
            }
            MoveObjectType_::Other(s) => DynamicFieldInfo::try_extract_field_value(s),
        }
    }

    pub fn is(&self, s: &StructTag) -> bool {
        match &self.0 {
            MoveObjectType_::GasCoin => GasCoin::is_gas_coin(s),
            MoveObjectType_::StakedSui => StakedSui::is_staked_sui(s),
            MoveObjectType_::Coin(inner) => {
                Coin::is_coin(s) && s.type_params.len() == 1 && inner == &s.type_params[0]
            }
            MoveObjectType_::SuiBalanceAccumulatorField => accumulator_value_balance_type_maybe(s)
                .map(|t| GAS::is_gas_type(&t))
                .unwrap_or(false),
            MoveObjectType_::BalanceAccumulatorField(inner) => {
                accumulator_value_balance_type_maybe(s)
                    .map(|t| &t == inner)
                    .unwrap_or(false)
            }
            MoveObjectType_::Other(o) => s == o,
        }
    }

    pub fn other(&self) -> Option<&StructTag> {
        if let MoveObjectType_::Other(s) = &self.0 {
            Some(s)
        } else {
            None
        }
    }

    /// Returns the string representation of this object's type using the canonical display.
    pub fn to_canonical_string(&self, with_prefix: bool) -> String {
        StructTag::from(self.clone()).to_canonical_string(with_prefix)
    }

    /// Helper function to construct type parameters for balance accumulator fields
    /// Field<Key<Balance<T>>, U128> has two type params
    fn balance_accumulator_field_type_params(inner_type: TypeTag) -> Vec<TypeTag> {
        use crate::accumulator_root::{AccumulatorKey, U128};
        let balance_type = Balance::type_tag(inner_type);
        let key_type = AccumulatorKey::get_type_tag(&[balance_type]);
        let u128_type = U128::get_type_tag();
        vec![key_type, u128_type]
    }

    /// Map from T to Field<AccumulatorKey<Balance<T>>, U128>
    fn balance_accumulator_field_struct_tag(inner_type: TypeTag) -> StructTag {
        use crate::accumulator_root::{AccumulatorKey, U128};
        let balance_type = Balance::type_tag(inner_type);
        let key_type = AccumulatorKey::get_type_tag(&[balance_type]);
        let u128_type = U128::get_type_tag();
        DynamicFieldInfo::dynamic_field_type(key_type, u128_type)
    }
}

impl From<StructTag> for MoveObjectType {
    fn from(mut s: StructTag) -> Self {
        Self(if GasCoin::is_gas_coin(&s) {
            MoveObjectType_::GasCoin
        } else if Coin::is_coin(&s) {
            // unwrap safe because a coin has exactly one type parameter
            MoveObjectType_::Coin(s.type_params.pop().unwrap())
        } else if StakedSui::is_staked_sui(&s) {
            MoveObjectType_::StakedSui
        } else if let Some(balance_type) = accumulator_value_balance_type_maybe(&s) {
            if GAS::is_gas_type(&balance_type) {
                MoveObjectType_::SuiBalanceAccumulatorField
            } else {
                MoveObjectType_::BalanceAccumulatorField(balance_type)
            }
        } else {
            MoveObjectType_::Other(s)
        })
    }
}

impl From<MoveObjectType> for StructTag {
    fn from(t: MoveObjectType) -> Self {
        match t.0 {
            MoveObjectType_::GasCoin => GasCoin::type_(),
            MoveObjectType_::StakedSui => StakedSui::type_(),
            MoveObjectType_::Coin(inner) => Coin::type_(inner),
            MoveObjectType_::SuiBalanceAccumulatorField => {
                MoveObjectType::balance_accumulator_field_struct_tag(GAS::type_tag())
            }
            MoveObjectType_::BalanceAccumulatorField(inner) => {
                MoveObjectType::balance_accumulator_field_struct_tag(inner)
            }
            MoveObjectType_::Other(s) => s,
        }
    }
}

impl From<MoveObjectType> for TypeTag {
    fn from(o: MoveObjectType) -> TypeTag {
        let s: StructTag = o.into();
        TypeTag::Struct(Box::new(s))
    }
}

/// Whether this type is valid as a primitive (pure) transaction input.
pub fn is_primitive_type_tag(t: &TypeTag) -> bool {
    use TypeTag as T;

    match t {
        T::Bool | T::U8 | T::U16 | T::U32 | T::U64 | T::U128 | T::U256 | T::Address => true,
        T::Vector(inner) => is_primitive_type_tag(inner),
        T::Struct(st) => {
            let StructTag {
                address,
                module,
                name,
                type_params: type_args,
            } = &**st;
            let resolved_struct = (address, module.as_ident_str(), name.as_ident_str());
            // is id or..
            if resolved_struct == RESOLVED_SUI_ID {
                return true;
            }
            // is utf8 string
            if resolved_struct == RESOLVED_UTF8_STR {
                return true;
            }
            // is ascii string
            if resolved_struct == RESOLVED_ASCII_STR {
                return true;
            }
            // is option of a primitive
            resolved_struct == RESOLVED_STD_OPTION
                && type_args.len() == 1
                && is_primitive_type_tag(&type_args[0])
        }
        T::Signer => false,
    }
}

/// Type of a Sui object
#[derive(Clone, Serialize, Deserialize, Ord, PartialOrd, Eq, PartialEq, Debug)]
pub enum ObjectType {
    /// Move package containing one or more bytecode modules
    Package,
    /// A Move struct of the given type
    Struct(MoveObjectType),
}

impl From<&Object> for ObjectType {
    fn from(o: &Object) -> Self {
        o.data
            .type_()
            .map(|t| ObjectType::Struct(t.clone()))
            .unwrap_or(ObjectType::Package)
    }
}

impl TryFrom<ObjectType> for StructTag {
    type Error = anyhow::Error;

    fn try_from(o: ObjectType) -> Result<Self, anyhow::Error> {
        match o {
            ObjectType::Package => Err(anyhow!("Cannot create StructTag from Package")),
            ObjectType::Struct(move_object_type) => Ok(move_object_type.into()),
        }
    }
}

impl FromStr for ObjectType {
    type Err = anyhow::Error;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if s.to_lowercase() == PACKAGE {
            Ok(ObjectType::Package)
        } else {
            let tag = parse_sui_struct_tag(s)?;
            Ok(ObjectType::Struct(MoveObjectType::from(tag)))
        }
    }
}

#[derive(Clone, Serialize, Deserialize, Ord, PartialOrd, Eq, PartialEq, Debug)]
pub struct ObjectInfo {
    pub object_id: ObjectID,
    pub version: SequenceNumber,
    pub digest: ObjectDigest,
    pub type_: ObjectType,
    pub owner: Owner,
    pub previous_transaction: TransactionDigest,
}

impl ObjectInfo {
    pub fn new(oref: &ObjectRef, o: &Object) -> Self {
        let (object_id, version, digest) = *oref;
        Self {
            object_id,
            version,
            digest,
            type_: o.into(),
            owner: o.owner.clone(),
            previous_transaction: o.previous_transaction,
        }
    }

    pub fn from_object(object: &Object) -> Self {
        Self {
            object_id: object.id(),
            version: object.version(),
            digest: object.digest(),
            type_: object.into(),
            owner: object.owner.clone(),
            previous_transaction: object.previous_transaction,
        }
    }
}
const PACKAGE: &str = "package";
impl ObjectType {
    pub fn is_gas_coin(&self) -> bool {
        matches!(self, ObjectType::Struct(s) if s.is_gas_coin())
    }

    pub fn is_coin(&self) -> bool {
        matches!(self, ObjectType::Struct(s) if s.is_coin())
    }

    /// Return true if `self` is `0x2::coin::Coin<t>`
    pub fn is_coin_t(&self, t: &TypeTag) -> bool {
        matches!(self, ObjectType::Struct(s) if s.is_coin_t(t))
    }

    pub fn is_package(&self) -> bool {
        matches!(self, ObjectType::Package)
    }
}

impl From<ObjectInfo> for ObjectRef {
    fn from(info: ObjectInfo) -> Self {
        (info.object_id, info.version, info.digest)
    }
}

impl From<&ObjectInfo> for ObjectRef {
    fn from(info: &ObjectInfo) -> Self {
        (info.object_id, info.version, info.digest)
    }
}

/// ZBX: EVM-compatible address size = 20 bytes (last 20 of Blake2b256)
pub const SUI_ADDRESS_LENGTH: usize = 20;

#[serde_as]
#[derive(
    Eq, Default, PartialEq, Ord, PartialOrd, Copy, Clone, Hash, Serialize, Deserialize, JsonSchema,
)]
#[cfg_attr(feature = "fuzzing", derive(proptest_derive::Arbitrary))]
pub struct SuiAddress(
    #[schemars(with = "Hex")]
    #[serde_as(as = "Readable<Hex, _>")]
    [u8; SUI_ADDRESS_LENGTH],
);

impl SuiAddress {
    pub const ZERO: Self = Self([0u8; SUI_ADDRESS_LENGTH]);

    /// Convert the address to a byte buffer.
    pub fn to_vec(&self) -> Vec<u8> {
        self.0.to_vec()
    }

    /// Return a random SuiAddress.
    pub fn random_for_testing_only() -> Self {
        AccountAddress::random().into()
    }

    pub fn generate<R: rand::RngCore + rand::CryptoRng>(mut rng: R) -> Self {
        let buf: [u8; SUI_ADDRESS_LENGTH] = rng.r#gen();
        Self(buf)
    }

    /// Serialize an `Option<SuiAddress>` in Hex.
    pub fn optional_address_as_hex<S>(
        key: &Option<SuiAddress>,
        serializer: S,
    ) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(&key.map(Hex::encode).unwrap_or_default())
    }

    /// Deserialize into an `Option<SuiAddress>`.
    pub fn optional_address_from_hex<'de, D>(
        deserializer: D,
    ) -> Result<Option<SuiAddress>, D::Error>
    where
        D: serde::de::Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;
        let value = decode_bytes_hex(&s).map_err(serde::de::Error::custom)?;
        Ok(Some(value))
    }

    /// Return the underlying byte array of a SuiAddress.
    pub fn to_inner(self) -> [u8; SUI_ADDRESS_LENGTH] {
        self.0
    }

    /// Parse a SuiAddress from a byte array or buffer.
    pub fn from_bytes<T: AsRef<[u8]>>(bytes: T) -> Result<Self, SuiError> {
        <[u8; SUI_ADDRESS_LENGTH]>::try_from(bytes.as_ref())
            .map_err(|_| SuiErrorKind::InvalidAddress.into())
            .map(SuiAddress)
    }

    /// This derives a zkLogin address by parsing the iss and address_seed from [struct ZkLoginAuthenticator].
    /// Define as iss_bytes_len || iss_bytes || padded_32_byte_address_seed. This is to be differentiated with
    /// try_from_unpadded defined below.
    pub fn try_from_padded(inputs: &ZkLoginInputs) -> SuiResult<Self> {
        Ok((&PublicKey::from_zklogin_inputs(inputs)?).into())
    }

    /// Define as iss_bytes_len || iss_bytes || unpadded_32_byte_address_seed.
    pub fn try_from_unpadded(inputs: &ZkLoginInputs) -> SuiResult<Self> {
        let mut hasher = DefaultHash::default();
        hasher.update([SignatureScheme::ZkLoginAuthenticator.flag()]);
        let iss_bytes = inputs.get_iss().as_bytes();
        hasher.update([iss_bytes.len() as u8]);
        hasher.update(iss_bytes);
        hasher.update(inputs.get_address_seed().unpadded());
        // ZBX: EVM-style — last 20 bytes
          let hash = hasher.finalize().digest;
          Ok(SuiAddress(hash[12..].try_into().expect("ZBX: 20-byte slice")))
    }
}

impl From<ObjectID> for SuiAddress {
    fn from(object_id: ObjectID) -> SuiAddress {
        Self(object_id.into_bytes())
    }
}

impl From<AccountAddress> for SuiAddress {
    fn from(address: AccountAddress) -> SuiAddress {
        Self(address.into_bytes())
    }
}

impl TryFrom<&[u8]> for SuiAddress {
    type Error = SuiError;

    /// Tries to convert the provided byte array into a SuiAddress.
    fn try_from(bytes: &[u8]) -> Result<Self, SuiError> {
        Self::from_bytes(bytes)
    }
}

impl TryFrom<Vec<u8>> for SuiAddress {
    type Error = SuiError;

    /// Tries to convert the provided byte buffer into a SuiAddress.
    fn try_from(bytes: Vec<u8>) -> Result<Self, SuiError> {
        Self::from_bytes(bytes)
    }
}

impl AsRef<[u8]> for SuiAddress {
    fn as_ref(&self) -> &[u8] {
        &self.0[..]
    }
}

impl FromStr for SuiAddress {
    type Err = anyhow::Error;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        decode_bytes_hex(s).map_err(|e| anyhow!(e))
    }
}

impl<T: SuiPublicKey> From<&T> for SuiAddress {
    fn from(pk: &T) -> Self {
        let mut hasher = DefaultHash::default();
        hasher.update([T::SIGNATURE_SCHEME.flag()]);
        hasher.update(pk);
        let g_arr = hasher.finalize();
        SuiAddress(g_arr.digest)
    }
}

impl From<&PublicKey> for SuiAddress {
    fn from(pk: &PublicKey) -> Self {
        let mut hasher = DefaultHash::default();
        hasher.update([pk.flag()]);
        hasher.update(pk);
        let g_arr = hasher.finalize();
        SuiAddress(g_arr.digest)
    }
}

impl From<&MultiSigPublicKey> for SuiAddress {
    /// Derive a SuiAddress from [struct MultiSigPublicKey]. A MultiSig address
    /// is defined as the 32-byte Blake2b hash of serializing the flag, the
    /// threshold, concatenation of all n flag, public keys and
    /// its weight. `flag_MultiSig || threshold || flag_1 || pk_1 || weight_1
    /// || ... || flag_n || pk_n || weight_n`.
    ///
    /// When flag_i is ZkLogin, pk_i refers to [struct ZkLoginPublicIdentifier]
    /// derived from padded address seed in bytes and iss.
    fn from(multisig_pk: &MultiSigPublicKey) -> Self {
        let mut hasher = DefaultHash::default();
        hasher.update([SignatureScheme::MultiSig.flag()]);
        hasher.update(multisig_pk.threshold().to_le_bytes());
        multisig_pk.pubkeys().iter().for_each(|(pk, w)| {
            hasher.update([pk.flag()]);
            hasher.update(pk.as_ref());
            hasher.update(w.to_le_bytes());
        });
        SuiAddress(hasher.finalize().digest)
    }
}

/// Sui address for [struct ZkLoginAuthenticator] is defined as the black2b hash of
/// [zklogin_flag || iss_bytes_length || iss_bytes || unpadded_address_seed_in_bytes].
impl TryFrom<&ZkLoginAuthenticator> for SuiAddress {
    type Error = SuiError;
    fn try_from(authenticator: &ZkLoginAuthenticator) -> SuiResult<Self> {
        SuiAddress::try_from_unpadded(&authenticator.inputs)
    }
}

impl TryFrom<&GenericSignature> for SuiAddress {
    type Error = SuiError;
    /// Derive a SuiAddress from a serialized signature in Sui [GenericSignature].
    fn try_from(sig: &GenericSignature) -> SuiResult<Self> {
        match sig {
            GenericSignature::Signature(sig) => {
                let scheme = sig.scheme();
                let pub_key_bytes = sig.public_key_bytes();
                let pub_key = PublicKey::try_from_bytes(scheme, pub_key_bytes).map_err(|_| {
                    SuiErrorKind::InvalidSignature {
                        error: "Cannot parse pubkey".to_string(),
                    }
                })?;
                Ok(SuiAddress::from(&pub_key))
            }
            GenericSignature::MultiSig(ms) => Ok(ms.get_pk().into()),
            GenericSignature::MultiSigLegacy(ms) => {
                Ok(crate::multisig::MultiSig::try_from(ms.clone())
                    .map_err(|_| SuiErrorKind::InvalidSignature {
                        error: "Invalid legacy multisig".to_string(),
                    })?
                    .get_pk()
                    .into())
            }
            GenericSignature::ZkLoginAuthenticator(zklogin) => {
                SuiAddress::try_from_unpadded(&zklogin.inputs)
            }
            GenericSignature::PasskeyAuthenticator(s) => Ok(SuiAddress::from(&s.get_pk()?)),
        }
    }
}

impl fmt::Display for SuiAddress {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "0x{}", Hex::encode(self.0))
    }
}

impl fmt::Debug for SuiAddress {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> Result<(), fmt::Error> {
        write!(f, "0x{}", Hex::encode(self.0))
    }
}

/// Generate a fake SuiAddress with repeated one byte.
pub fn dbg_addr(name: u8) -> SuiAddress {
    let addr = [name; SUI_ADDRESS_LENGTH];
    SuiAddress(addr)
}

#[derive(
    Eq, PartialEq, Ord, PartialOrd, Copy, Clone, Hash, Serialize, Deserialize, JsonSchema, Debug,
)]
pub struct ExecutionDigests {
    pub transaction: TransactionDigest,
    pub effects: TransactionEffectsDigest,
}

impl ExecutionDigests {
    pub fn new(transaction: TransactionDigest, effects: TransactionEffectsDigest) -> Self {
        Self {
            transaction,
            effects,
        }
    }

    pub fn random() -> Self {
        Self {
            transaction: TransactionDigest::random(),
            effects: TransactionEffectsDigest::random(),
        }
    }
}

#[derive(Clone, Eq, PartialEq, Serialize, Deserialize, Debug)]
pub struct ExecutionData {
    pub transaction: Transaction,
    pub effects: TransactionEffects,
}

impl ExecutionData {
    pub fn new(transaction: Transaction, effects: TransactionEffects) -> ExecutionData {
        debug_assert_eq!(transaction.digest(), effects.transaction_digest());
        Self {
            transaction,
            effects,
        }
    }

    pub fn digests(&self) -> ExecutionDigests {
        self.effects.execution_digests()
    }
}

#[derive(Clone, Eq, PartialEq, Debug)]
pub struct VerifiedExecutionData {
    pub transaction: VerifiedTransaction,
    pub effects: TransactionEffects,
}

impl VerifiedExecutionData {
    pub fn new(transaction: VerifiedTransaction, effects: TransactionEffects) -> Self {
        debug_assert_eq!(transaction.digest(), effects.transaction_digest());
        Self {
            transaction,
            effects,
        }
    }

    pub fn new_unchecked(data: ExecutionData) -> Self {
        Self {
            transaction: VerifiedTransaction::new_unchecked(data.transaction),
            effects: data.effects,
        }
    }

    pub fn into_inner(self) -> ExecutionData {
        ExecutionData {
            transaction: self.transaction.into_inner(),
            effects: self.effects,
        }
    }

    pub fn digests(&self) -> ExecutionDigests {
        self.effects.execution_digests()
    }
}

pub const STD_OPTION_MODULE_NAME: &IdentStr = ident_str!("option");
pub const STD_OPTION_STRUCT_NAME: &IdentStr = ident_str!("Option");
pub const RESOLVED_STD_OPTION: (&AccountAddress, &IdentStr, &IdentStr) = (
    &MOVE_STDLIB_ADDRESS,
    STD_OPTION_MODULE_NAME,
    STD_OPTION_STRUCT_NAME,
);

pub const STD_ASCII_MODULE_NAME: &IdentStr = ident_str!("ascii");
pub const STD_ASCII_STRUCT_NAME: &IdentStr = ident_str!("String");
pub const RESOLVED_ASCII_STR: (&AccountAddress, &IdentStr, &IdentStr) = (
    &MOVE_STDLIB_ADDRESS,
    STD_ASCII_MODULE_NAME,
    STD_ASCII_STRUCT_NAME,
);

pub const STD_UTF8_MODULE_NAME: &IdentStr = ident_str!("string");
pub const STD_UTF8_STRUCT_NAME: &IdentStr = ident_str!("String");
pub const RESOLVED_UTF8_STR: (&AccountAddress, &IdentStr, &IdentStr) = (
    &MOVE_STDLIB_ADDRESS,
    STD_UTF8_MODULE_NAME,
    STD_UTF8_STRUCT_NAME,
);

pub const STD_TYPE_NAME_MODULE_NAME: &IdentStr = ident_str!("type_name");
pub const STD_TYPE_NAME_STRUCT_NAME: &IdentStr = ident_str!("TypeName");
pub const RESOLVED_STD_TYPE_NAME: (&AccountAddress, &IdentStr, &IdentStr) = (
    &MOVE_STDLIB_ADDRESS,
    STD_TYPE_NAME_MODULE_NAME,
    STD_TYPE_NAME_STRUCT_NAME,
);

pub const TX_CONTEXT_MODULE_NAME: &IdentStr = ident_str!("tx_context");
pub const TX_CONTEXT_STRUCT_NAME: &IdentStr = ident_str!("TxContext");
pub const RESOLVED_TX_CONTEXT: (&AccountAddress, &IdentStr, &IdentStr) = (
    &SUI_FRAMEWORK_ADDRESS,
    TX_CONTEXT_MODULE_NAME,
    TX_CONTEXT_STRUCT_NAME,
);

pub const URL_MODULE_NAME: &IdentStr = ident_str!("url");
pub const URL_STRUCT_NAME: &IdentStr = ident_str!("Url");

pub const VEC_MAP_MODULE_NAME: &IdentStr = ident_str!("vec_map");
pub const VEC_MAP_STRUCT_NAME: &IdentStr = ident_str!("VecMap");
pub const VEC_MAP_ENTRY_STRUCT_NAME: &IdentStr = ident_str!("Entry");

pub fn move_ascii_str_layout() -> A::MoveStructLayout {
    A::MoveStructLayout {
        type_: StructTag {
            address: MOVE_STDLIB_ADDRESS,
            module: STD_ASCII_MODULE_NAME.to_owned(),
            name: STD_ASCII_STRUCT_NAME.to_owned(),
            type_params: vec![],
        },
        fields: vec![A::MoveFieldLayout::new(
            ident_str!("bytes").into(),
            A::MoveTypeLayout::Vector(Box::new(A::MoveTypeLayout::U8)),
        )],
    }
}

pub fn move_utf8_str_layout() -> A::MoveStructLayout {
    A::MoveStructLayout {
        type_: StructTag {
            address: MOVE_STDLIB_ADDRESS,
            module: STD_UTF8_MODULE_NAME.to_owned(),
            name: STD_UTF8_STRUCT_NAME.to_owned(),
            type_params: vec![],
        },
        fields: vec![A::MoveFieldLayout::new(
            ident_str!("bytes").into(),
            A::MoveTypeLayout::Vector(Box::new(A::MoveTypeLayout::U8)),
        )],
    }
}

pub fn url_layout() -> A::MoveStructLayout {
    A::MoveStructLayout {
        type_: StructTag {
            address: SUI_FRAMEWORK_ADDRESS,
            module: URL_MODULE_NAME.to_owned(),
            name: URL_STRUCT_NAME.to_owned(),
            type_params: vec![],
        },
        fields: vec![A::MoveFieldLayout::new(
            ident_str!("url").to_owned(),
            A::MoveTypeLayout::Struct(Box::new(move_ascii_str_layout())),
        )],
    }
}

pub fn type_name_layout() -> A::MoveStructLayout {
    A::MoveStructLayout {
        type_: StructTag {
            address: MOVE_STDLIB_ADDRESS,
            module: STD_TYPE_NAME_MODULE_NAME.to_owned(),
            name: STD_TYPE_NAME_STRUCT_NAME.to_owned(),
            type_params: vec![],
        },
        fields: vec![A::MoveFieldLayout::new(
            ident_str!("name").into(),
            A::MoveTypeLayout::Struct(Box::new(move_ascii_str_layout())),
        )],
    }
}

// The Rust representation of the Move `TxContext`.
// This struct must be kept in sync with the Move `TxContext` definition.
// Moving forward we are going to zero all fields of the Move `TxContext`
// and use native functions to retrieve info about the transaction.
// However we cannot remove the Move type and so this struct is going to
// be the Rust equivalent to the Move `TxContext` for legacy usages.
//
// `TxContext` in Rust (see below) is going to be purely used in Rust and can
// evolve as needed without worrying any compatibility with Move.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct MoveLegacyTxContext {
    // Signer/sender of the transaction
    sender: AccountAddress,
    // Digest of the current transaction
    digest: Vec<u8>,
    // The current epoch number
    epoch: EpochId,
    // Timestamp that the epoch started at
    epoch_timestamp_ms: CheckpointTimestamp,
    // Number of `ObjectID`'s generated during execution of the current transaction
    ids_created: u64,
}

impl From<&TxContext> for MoveLegacyTxContext {
    fn from(tx_context: &TxContext) -> Self {
        Self {
            sender: tx_context.sender,
            digest: tx_context.digest.clone(),
            epoch: tx_context.epoch,
            epoch_timestamp_ms: tx_context.epoch_timestamp_ms,
            ids_created: tx_context.ids_created,
        }
    }
}

// Information about the transaction context.
// This struct is not related to Move and can evolve as needed/required.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct TxContext {
    /// Sender of the transaction
    sender: AccountAddress,
    /// Digest of the current transaction
    digest: Vec<u8>,
    /// The current epoch number
    epoch: EpochId,
    /// Timestamp that the epoch started at
    epoch_timestamp_ms: CheckpointTimestamp,
    /// Number of `ObjectID`'s generated during execution of the current transaction
    ids_created: u64,
    // Reference gas price
    rgp: u64,
    // gas price passed to transaction as input
    gas_price: u64,
    // gas budget passed to transaction as input
    gas_budget: u64,
    // address of the sponsor if any
    sponsor: Option<AccountAddress>,
    // whether the `TxContext` is native or not
    // (TODO: once we version execution we could drop this field)
    is_native: bool,
}

#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum TxContextKind {
    // No TxContext
    None,
    // &mut TxContext
    Mutable,
    // &TxContext
    Immutable,
}

impl TxContext {
    pub fn new(
        sender: &SuiAddress,
        digest: &TransactionDigest,
        epoch_data: &EpochData,
        rgp: u64,
        gas_price: u64,
        gas_budget: u64,
        sponsor: Option<SuiAddress>,
        protocol_config: &ProtocolConfig,
    ) -> Self {
        Self::new_from_components(
            sender,
            digest,
            &epoch_data.epoch_id(),
            epoch_data.epoch_start_timestamp(),
            rgp,
            gas_price,
            gas_budget,
            sponsor,
            protocol_config,
        )
    }

    pub fn new_from_components(
        sender: &SuiAddress,
        digest: &TransactionDigest,
        epoch_id: &EpochId,
        epoch_timestamp_ms: u64,
        rgp: u64,
        gas_price: u64,
        gas_budget: u64,
        sponsor: Option<SuiAddress>,
        protocol_config: &ProtocolConfig,
    ) -> Self {
        Self {
            sender: AccountAddress::new(sender.0),
            digest: digest.into_inner().to_vec(),
            epoch: *epoch_id,
            epoch_timestamp_ms,
            ids_created: 0,
            rgp,
            gas_price,
            gas_budget,
            sponsor: sponsor.map(|s| s.into()),
            is_native: protocol_config.move_native_context(),
        }
    }

    /// Returns whether the type signature is &mut TxContext, &TxContext, or none of the above.
    pub fn kind(view: &CompiledModule, s: &SignatureToken) -> TxContextKind {
        use SignatureToken as S;
        let (kind, s) = match s {
            S::MutableReference(s) => (TxContextKind::Mutable, s),
            S::Reference(s) => (TxContextKind::Immutable, s),
            _ => return TxContextKind::None,
        };

        let S::Datatype(idx) = &**s else {
            return TxContextKind::None;
        };

        if resolve_struct(view, *idx) == RESOLVED_TX_CONTEXT {
            kind
        } else {
            TxContextKind::None
        }
    }

    pub fn type_() -> StructTag {
        StructTag {
            address: SUI_FRAMEWORK_ADDRESS,
            module: TX_CONTEXT_MODULE_NAME.to_owned(),
            name: TX_CONTEXT_STRUCT_NAME.to_owned(),
            type_params: vec![],
        }
    }

    pub fn epoch(&self) -> EpochId {
        self.epoch
    }

    pub fn sender(&self) -> SuiAddress {
        self.sender.into()
    }

    pub fn epoch_timestamp_ms(&self) -> u64 {
        self.epoch_timestamp_ms
    }

    /// Return the transaction digest, to include in new objects
    pub fn digest(&self) -> TransactionDigest {
        TransactionDigest::new(self.digest.clone().try_into().unwrap())
    }

    pub fn sponsor(&self) -> Option<SuiAddress> {
        self.sponsor.map(SuiAddress::from)
    }

    pub fn rgp(&self) -> u64 {
        self.rgp
    }

    pub fn gas_price(&self) -> u64 {
        self.gas_price
    }

    pub fn gas_budget(&self) -> u64 {
        self.gas_budget
    }

    pub fn ids_created(&self) -> u64 {
        self.ids_created
    }

    /// Derive a globally unique object ID by hashing self.digest | self.ids_created
    pub fn fresh_id(&mut self) -> ObjectID {
        let id = ObjectID::derive_id(self.digest(), self.ids_created);

        self.ids_created += 1;
        id
    }

    pub fn to_bcs_legacy_context(&self) -> Vec<u8> {
        let move_context: MoveLegacyTxContext = if self.is_native {
            let tx_context = &TxContext {
                sender: AccountAddress::ZERO,
                digest: self.digest.clone(),
                epoch: 0,
                epoch_timestamp_ms: 0,
                ids_created: 0,
                rgp: 0,
                gas_price: 0,
                gas_budget: 0,
                sponsor: None,
                is_native: true,
            };
            tx_context.into()
        } else {
            self.into()
        };
        bcs::to_bytes(&move_context).unwrap()
    }

    pub fn to_vec(&self) -> Vec<u8> {
        bcs::to_bytes(&self).unwrap()
    }

    /// Updates state of the context instance. It's intended to use
    /// when mutable context is passed over some boundary via
    /// serialize/deserialize and this is the reason why this method
    /// consumes the other context..
    pub fn update_state(&mut self, other: MoveLegacyTxContext) -> Result<(), ExecutionError> {
        if !self.is_native {
            if self.sender != other.sender
                || self.digest != other.digest
                || other.ids_created < self.ids_created
            {
                return Err(ExecutionError::new_with_source(
                    ExecutionErrorKind::InvariantViolation,
                    "Immutable fields for TxContext changed",
                ));
            }
            self.ids_created = other.ids_created;
        }
        Ok(())
    }

    //
    // Move test only API
    //
    pub fn replace(
        &mut self,
        sender: AccountAddress,
        tx_hash: Vec<u8>,
        epoch: u64,
        epoch_timestamp_ms: u64,
        ids_created: u64,
        rgp: u64,
        gas_price: u64,
        gas_budget: u64,
        sponsor: Option<AccountAddress>,
    ) {
        self.sender = sender;
        self.digest = tx_hash;
        self.epoch = epoch;
        self.epoch_timestamp_ms = epoch_timestamp_ms;
        self.ids_created = ids_created;
        self.rgp = rgp;
        self.gas_price = gas_price;
        self.gas_budget = gas_budget;
        self.sponsor = sponsor;
    }
}

// TODO: rename to version
impl SequenceNumber {
    pub const MIN: SequenceNumber = SequenceNumber(u64::MIN);
    pub const MAX: SequenceNumber = SequenceNumber(0x7fff_ffff_ffff_ffff);
    pub const CANCELLED_READ: SequenceNumber = SequenceNumber(SequenceNumber::MAX.value() + 1);
    pub const CONGESTED: SequenceNumber = SequenceNumber(SequenceNumber::MAX.value() + 2);
    pub const RANDOMNESS_UNAVAILABLE: SequenceNumber =
        SequenceNumber(SequenceNumber::MAX.value() + 3);
    // Used to represent a sequence number whose value is unknown.
    // For internal use only. This should never appear on chain.
    pub const UNKNOWN: SequenceNumber = SequenceNumber(SequenceNumber::MAX.value() + 4);

    pub const fn new() -> Self {
        SequenceNumber(0)
    }

    pub const fn value(&self) -> u64 {
        self.0
    }

    pub const fn from_u64(u: u64) -> Self {
        SequenceNumber(u)
    }

    pub fn increment(&mut self) {
        assert_ne!(self.0, u64::MAX);
        self.0 += 1;
    }

    pub fn increment_to(&mut self, next: SequenceNumber) {
        debug_assert!(*self < next, "Not an increment: {} to {}", self, next);
        *self = next;
    }

    pub fn decrement(&mut self) {
        assert_ne!(self.0, 0);
        self.0 -= 1;
    }

    pub fn decrement_to(&mut self, prev: SequenceNumber) {
        debug_assert!(prev < *self, "Not a decrement: {} to {}", self, prev);
        *self = prev;
    }

    /// Returns a new sequence number that is greater than all `SequenceNumber`s in `inputs`,
    /// assuming this operation will not overflow.
    #[must_use]
    pub fn lamport_increment(inputs: impl IntoIterator<Item = SequenceNumber>) -> SequenceNumber {
        let max_input = inputs.into_iter().fold(SequenceNumber::new(), max);

        // TODO: Ensure this never overflows.
        // Option 1: Freeze the object when sequence number reaches MAX.
        // Option 2: Reject tx with MAX sequence number.
        // Issue #182.
        assert_ne!(max_input.0, u64::MAX);

        SequenceNumber(max_input.0 + 1)
    }

    pub fn is_cancelled(&self) -> bool {
        self == &SequenceNumber::CANCELLED_READ
            || self == &SequenceNumber::CONGESTED
            || self == &SequenceNumber::RANDOMNESS_UNAVAILABLE
    }

    pub fn is_valid(&self) -> bool {
        self < &SequenceNumber::MAX
    }
}

impl From<SequenceNumber> for u64 {
    fn from(val: SequenceNumber) -> Self {
        val.0
    }
}

impl From<u64> for SequenceNumber {
    fn from(value: u64) -> Self {
        SequenceNumber(value)
    }
}

impl From<SequenceNumber> for usize {
    fn from(value: SequenceNumber) -> Self {
        value.0 as usize
    }
}

impl ObjectID {
    /// The number of bytes in an address.
    pub const LENGTH: usize = AccountAddress::LENGTH;
    /// Hex address: 0x0
    pub const ZERO: Self = Self::new([0u8; Self::LENGTH]);
    pub const MAX: Self = Self::new([0xff; Self::LENGTH]);
    /// Create a new ObjectID
    pub const fn new(obj_id: [u8; Self::LENGTH]) -> Self {
        Self(AccountAddress::new(obj_id))
    }

    /// Const fn variant of `<ObjectID as From<AccountAddress>>::from`
    pub const fn from_address(addr: AccountAddress) -> Self {
        Self(addr)
    }

    /// Return a random ObjectID.
    pub fn random() -> Self {
        Self::from(AccountAddress::random())
    }

    /// Return a random ObjectID from a given RNG.
    pub fn random_from_rng<R>(rng: &mut R) -> Self
    where
        R: AllowedRng,
    {
        let buf: [u8; Self::LENGTH] = rng.r#gen();
        ObjectID::new(buf)
    }

    /// Return the underlying bytes buffer of the ObjectID.
    pub fn to_vec(&self) -> Vec<u8> {
        self.0.to_vec()
    }

    /// Parse the ObjectID from byte array or buffer.
    pub fn from_bytes<T: AsRef<[u8]>>(bytes: T) -> Result<Self, ObjectIDParseError> {
        <[u8; Self::LENGTH]>::try_from(bytes.as_ref())
            .map_err(|_| ObjectIDParseError::TryFromSliceError)
            .map(ObjectID::new)
    }

    /// Return the underlying bytes array of the ObjectID.
    pub fn into_bytes(self) -> [u8; Self::LENGTH] {
        self.0.into_bytes()
    }

    /// Make an ObjectID with padding 0s before the single byte.
    pub const fn from_single_byte(byte: u8) -> ObjectID {
        let mut bytes = [0u8; Self::LENGTH];
        bytes[Self::LENGTH - 1] = byte;
        ObjectID::new(bytes)
    }

    /// System objects have IDs that fit in the last 8 bytes (24 leading zero bytes).
    pub fn is_system_object(&self) -> bool {
        self.0.as_ref()[..24] == [0u8; 24]
    }

    /// Convert from hex string to ObjectID where the string is prefixed with 0x
    /// Padding 0s if the string is too short.
    pub fn from_hex_literal(literal: &str) -> Result<Self, ObjectIDParseError> {
        if !literal.starts_with("0x") {
            return Err(ObjectIDParseError::HexLiteralPrefixMissing);
        }

        let hex_len = literal.len() - 2;

        // If the string is too short, pad it
        if hex_len < Self::LENGTH * 2 {
            let mut hex_str = String::with_capacity(Self::LENGTH * 2);
            for _ in 0..Self::LENGTH * 2 - hex_len {
                hex_str.push('0');
            }
            hex_str.push_str(&literal[2..]);
            Self::from_str(&hex_str)
        } else {
            Self::from_str(&literal[2..])
        }
    }

    /// Create an ObjectID from `TransactionDigest` and `creation_num`.
    /// Caller is responsible for ensuring that `creation_num` is fresh
    pub fn derive_id(digest: TransactionDigest, creation_num: u64) -> Self {
        let mut hasher = DefaultHash::default();
        hasher.update([HashingIntentScope::RegularObjectId as u8]);
        hasher.update(digest);
        hasher.update(creation_num.to_le_bytes());
        let hash = hasher.finalize();

        // truncate into an ObjectID.
        // OK to access slice because digest should never be shorter than ObjectID::LENGTH.
        ObjectID::try_from(&hash.as_ref()[0..ObjectID::LENGTH]).unwrap()
    }

    /// Incremenent the ObjectID by usize IDs, assuming the ObjectID hex is a number represented as an array of bytes
    pub fn advance(&self, step: usize) -> Result<ObjectID, anyhow::Error> {
        let mut curr_vec = self.to_vec();
        let mut step_copy = step;

        let mut carry = 0;
        for idx in (0..Self::LENGTH).rev() {
            if step_copy == 0 {
                // Nothing else to do
                break;
            }
            // Extract the relevant part
            let g = (step_copy % 0x100) as u16;
            // Shift to next group
            step_copy >>= 8;
            let mut val = curr_vec[idx] as u16;
            (carry, val) = ((val + carry + g) / 0x100, (val + carry + g) % 0x100);
            curr_vec[idx] = val as u8;
        }

        if carry > 0 {
            return Err(anyhow!("Increment will cause overflow"));
        }
        ObjectID::try_from(curr_vec).map_err(|w| w.into())
    }

    /// Increment the ObjectID by one, assuming the ObjectID hex is a number represented as an array of bytes
    pub fn next_increment(&self) -> Result<ObjectID, anyhow::Error> {
        let mut prev_val = self.to_vec();
        let mx = [0xFF; Self::LENGTH];

        if prev_val == mx {
            return Err(anyhow!("Increment will cause overflow"));
        }

        // This logic increments the integer representation of an ObjectID u8 array
        for idx in (0..Self::LENGTH).rev() {
            if prev_val[idx] == 0xFF {
                prev_val[idx] = 0;
            } else {
                prev_val[idx] += 1;
                break;
            };
        }
        ObjectID::try_from(prev_val.clone()).map_err(|w| w.into())
    }

    /// Create `count` object IDs starting with one at `offset`
    pub fn in_range(offset: ObjectID, count: u64) -> Result<Vec<ObjectID>, anyhow::Error> {
        let mut ret = Vec::new();
        let mut prev = offset;
        for o in 0..count {
            if o != 0 {
                prev = prev.next_increment()?;
            }
            ret.push(prev);
        }
        Ok(ret)
    }

    /// Return the full hex string with 0x prefix without removing trailing 0s. Prefer this
    /// over [fn to_hex_literal] if the string needs to be fully preserved.
    pub fn to_hex_uncompressed(&self) -> String {
        format!("{self}")
    }

    pub fn is_clock(&self) -> bool {
        *self == SUI_CLOCK_OBJECT_ID
    }
}

impl From<SuiAddress> for ObjectID {
    fn from(address: SuiAddress) -> ObjectID {
        let tmp: AccountAddress = address.into();
        tmp.into()
    }
}

impl From<AccountAddress> for ObjectID {
    fn from(address: AccountAddress) -> Self {
        Self(address)
    }
}

impl fmt::Display for ObjectID {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> Result<(), fmt::Error> {
        write!(f, "0x{}", Hex::encode(self.0))
    }
}

impl fmt::Debug for ObjectID {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> Result<(), fmt::Error> {
        write!(f, "0x{}", Hex::encode(self.0))
    }
}

impl AsRef<[u8]> for ObjectID {
    fn as_ref(&self) -> &[u8] {
        self.0.as_slice()
    }
}

impl TryFrom<&[u8]> for ObjectID {
    type Error = ObjectIDParseError;

    /// Tries to convert the provided byte array into ObjectID.
    fn try_from(bytes: &[u8]) -> Result<ObjectID, ObjectIDParseError> {
        Self::from_bytes(bytes)
    }
}

impl TryFrom<Vec<u8>> for ObjectID {
    type Error = ObjectIDParseError;

    /// Tries to convert the provided byte buffer into ObjectID.
    fn try_from(bytes: Vec<u8>) -> Result<ObjectID, ObjectIDParseError> {
        Self::from_bytes(bytes)
    }
}

impl FromStr for ObjectID {
    type Err = ObjectIDParseError;

    /// Parse ObjectID from hex string with or without 0x prefix, pad with 0s if needed.
    fn from_str(s: &str) -> Result<Self, ObjectIDParseError> {
        decode_bytes_hex(s).or_else(|_| Self::from_hex_literal(s))
    }
}

impl std::ops::Deref for ObjectID {
    type Target = AccountAddress;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

/// Generate a fake ObjectID with repeated one byte.
pub fn dbg_object_id(name: u8) -> ObjectID {
    ObjectID::new([name; ObjectID::LENGTH])
}

#[derive(PartialEq, Eq, Clone, Debug, thiserror::Error)]
pub enum ObjectIDParseError {
    #[error("ObjectID hex literal must start with 0x")]
    HexLiteralPrefixMissing,

    #[error("Could not convert from bytes slice")]
    TryFromSliceError,
}

impl From<ObjectID> for AccountAddress {
    fn from(obj_id: ObjectID) -> Self {
        obj_id.0
    }
}

impl From<SuiAddress> for AccountAddress {
    fn from(address: SuiAddress) -> Self {
        Self::new(address.0)
    }
}

/// Hex serde for AccountAddress
struct HexAccountAddress;

impl SerializeAs<AccountAddress> for HexAccountAddress {
    fn serialize_as<S>(value: &AccountAddress, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        Hex::serialize_as(value, serializer)
    }
}

impl<'de> DeserializeAs<'de, AccountAddress> for HexAccountAddress {
    fn deserialize_as<D>(deserializer: D) -> Result<AccountAddress, D::Error>
    where
        D: Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;
        if s.starts_with("0x") {
            AccountAddress::from_hex_literal(&s)
        } else {
            AccountAddress::from_hex(&s)
        }
        .map_err(to_custom_deser_error::<'de, D, _>)
    }
}

impl fmt::Display for MoveObjectType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> std::fmt::Result {
        let s: StructTag = self.clone().into();
        write!(
            f,
            "{}",
            to_sui_struct_tag_string(&s).map_err(fmt::Error::custom)?
        )
    }
}

impl fmt::Display for ObjectType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ObjectType::Package => write!(f, "{}", PACKAGE),
            ObjectType::Struct(t) => write!(f, "{}", t),
        }
    }
}

// SizeOneVec is a wrapper around Vec<T> that enforces the size of the vec to be 1.
// This seems pointless, but it allows us to have fields in protocol messages that are
// current enforced to be of size 1, but might later allow other sizes, and to have
// that constraint enforced in the serialization/deserialization layer, instead of
// requiring manual input validation.
#[derive(Debug, Deserialize, Clone, Eq, PartialEq, Hash, Ord, PartialOrd)]
#[serde(try_from = "Vec<T>")]
pub struct SizeOneVec<T> {
    e: T,
}

impl<T> SizeOneVec<T> {
    pub fn new(e: T) -> Self {
        Self { e }
    }

    pub fn element(&self) -> &T {
        &self.e
    }

    pub fn element_mut(&mut self) -> &mut T {
        &mut self.e
    }

    pub fn into_inner(self) -> T {
        self.e
    }

    pub fn iter(&self) -> std::iter::Once<&T> {
        std::iter::once(&self.e)
    }
}

impl<T> Serialize for SizeOneVec<T>
where
    T: Serialize,
{
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut seq = serializer.serialize_seq(Some(1))?;
        seq.serialize_element(&self.e)?;
        seq.end()
    }
}

impl<T> TryFrom<Vec<T>> for SizeOneVec<T> {
    type Error = anyhow::Error;

    fn try_from(mut v: Vec<T>) -> Result<Self, Self::Error> {
        if v.len() != 1 {
            Err(anyhow!("Expected a vec of size 1"))
        } else {
            Ok(SizeOneVec {
                e: v.pop().unwrap(),
            })
        }
    }
}

#[test]
fn test_size_one_vec_is_transparent() {
    let regular = vec![42u8];
    let size_one = SizeOneVec::new(42u8);

    // Vec -> SizeOneVec serialization is transparent
    let regular_ser = bcs::to_bytes(&regular).unwrap();
    let size_one_deser = bcs::from_bytes::<SizeOneVec<u8>>(&regular_ser).unwrap();
    assert_eq!(size_one, size_one_deser);

    // other direction works too
    let size_one_ser = bcs::to_bytes(&SizeOneVec::new(43u8)).unwrap();
    let regular_deser = bcs::from_bytes::<Vec<u8>>(&size_one_ser).unwrap();
    assert_eq!(regular_deser, vec![43u8]);

    // we get a deserialize error when deserializing a vec with size != 1
    let empty_ser = bcs::to_bytes(&Vec::<u8>::new()).unwrap();
    bcs::from_bytes::<SizeOneVec<u8>>(&empty_ser).unwrap_err();

    let size_greater_than_one_ser = bcs::to_bytes(&vec![1u8, 2u8]).unwrap();
    bcs::from_bytes::<SizeOneVec<u8>>(&size_greater_than_one_ser).unwrap_err();
}
