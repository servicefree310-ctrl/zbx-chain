# Zebvix Chain — Full Setup Guide

**Company:** Zebvix Technologies Pvt Ltd (India)  
**Chain:** Zebvix Mainnet | **Chain ID:** `zebvix-mainnet-1`  
**Token:** ZBX (9 decimals) | **Binary:** `zebvix-node`  
**Base:** Sui mainnet-v1.69.2  

---

## What This Archive Contains

```
zebvix-chain-patches/
├── crates/
│   ├── sui-types/src/
│   │   ├── gas_coin.rs        ← ZBX tokenomics (150M max, halvings, gas split)
│   │   └── base_types.rs      ← 20-byte EVM address (last 20 of Blake2b256)
│   ├── sui-node/
│   │   └── Cargo.toml         ← Binary renamed to zebvix-node
│   └── sui-framework/packages/zebvix/sources/
│       ├── zbx_token.move     ← ZBX token (2M genesis, 150M max, halving)
│       ├── pay_id.move        ← Pay ID system (rahul@zbx)
│       ├── staking_pool.move  ← Validator (120%) + Delegator (80%) APR
│       ├── master_pool.move   ← AMM base pool (anti-rug)
│       ├── sub_pool.move      ← Permissionless token pairs
│       └── founder_admin.move ← MultiSig 4/6 admin cap
├── scripts/
│   ├── apply_patches.sh       ← ONE-COMMAND: apply all patches to Sui clone
│   ├── step1_rename.sh
│   ├── step2_address.sh
│   ├── step3_constants.sh
│   ├── step4_multisig.sh
│   ├── step5_move.sh
│   └── step6_config.sh
└── INSTALL.md                 ← This file
```

---

## VPS Requirements

| Resource | Minimum | Recommended |
|----------|---------|-------------|
| RAM | 8 GB | 16 GB |
| CPU | 4 cores x86_64 | 8 cores |
| Disk | 100 GB SSD | 500 GB NVMe |
| OS | Ubuntu 22.04 LTS | Ubuntu 22.04 LTS |

---

## Step-by-Step Setup

### 1. Install Rust & build tools

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source ~/.cargo/env

apt-get update && apt-get install -y \
  git curl build-essential pkg-config libssl-dev cmake clang libpq-dev

# Install Sui CLI (for Move deployment)
cargo install --locked --version 1.69.2 sui
```

### 2. Clone Sui (exact version — mainnet-v1.69.2)

```bash
git clone \
  --branch mainnet-v1.69.2 \
  --depth 1 \
  https://github.com/MystenLabs/sui \
  ~/zebvix-node
```

### 3. Upload this archive to VPS

```bash
# On your LOCAL machine:
scp zebvix-chain-patches.tar.gz root@YOUR_VPS_IP:~/

# On VPS — extract:
cd ~
tar -xzf zebvix-chain-patches.tar.gz
```

### 4. Apply ALL patches (ONE command)

```bash
bash ~/zebvix-chain-patches/scripts/apply_patches.sh ~/zebvix-node
```

This copies:
- `gas_coin.rs` — ZBX tokenomics constants
- `base_types.rs` — 20-byte EVM address derivation
- `Cargo.toml` — zebvix-node binary
- All 6 Move modules

### 5. Build the node

```bash
cd ~/zebvix-node
cargo build --release --bin zebvix-node
# ~30-60 min first time

ls -lh target/release/zebvix-node
```

### 6. Initialize genesis + validator config

```bash
mkdir -p ~/zebvix-data

~/zebvix-node/target/release/zebvix-node \
  genesis \
  --working-dir ~/zebvix-data \
  --write-genesis-blob
```

### 7. Deploy Zebvix Move modules (after genesis)

```bash
cd ~/zebvix-node/crates/sui-framework/packages/zebvix

sui move publish \
  --gas-budget 200000000 \
  --json 2>&1 | tee ~/zebvix-data/deploy.log

grep '"packageId"' ~/zebvix-data/deploy.log
```

### 8. Run validator node

```bash
# Test run (foreground):
~/zebvix-node/target/release/zebvix-node \
  --config-path ~/zebvix-data/validator.yaml

# Production (systemd):
cat > /etc/systemd/system/zebvix-node.service << 'EOF'
[Unit]
Description=Zebvix Validator Node (ZBX)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/zebvix-data
ExecStart=/root/zebvix-node/target/release/zebvix-node \
  --config-path /root/zebvix-data/validator.yaml
Restart=always
RestartSec=10
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable zebvix-node
systemctl start zebvix-node
systemctl status zebvix-node
```

---

## Tokenomics Reference

| Parameter | Value |
|-----------|-------|
| Max Supply | 150,000,000 ZBX |
| Genesis Supply | 2,000,000 ZBX → founder wallet |
| Burn Cap | 75,000,000 ZBX (50% of max) |
| Decimals | 9 (1 ZBX = 1,000,000,000 MIST) |
| Gas: Validators | 72% |
| Gas: Treasury | 18% |
| Gas: Burn | 10% (until burn cap) |
| Block Reward Phase 1 | 0.1 ZBX (until 50M minted) |
| Block Reward Phase 2 | 0.05 ZBX (50M–100M minted) |
| Block Reward Phase 3 | 0.025 ZBX (100M+ minted) |

## Validator System

| Parameter | Value |
|-----------|-------|
| Max Validators | 41 slots |
| Min Self-Stake | 10,000 ZBX |
| Max Per Slot | 5,000,000 ZBX (self + delegators) |
| Validator APR | 120% on self-stake |
| Delegator APR | 80% on delegated amount |
| Delegation Bonus | +40% APR on total delegated in slot |
| Node Daily Reward | 5 ZBX/day (only node runners) |

## Address Format

| Property | Value |
|----------|-------|
| Length | 20 bytes (EVM-compatible) |
| Derivation | Last 20 bytes of Blake2b-256 of `[flag \|\| pubkey]` |
| Display | `0x` + 40 hex characters |
| Example | `0xa1b2c3d4e5f67890abcd1234567890abcdef1234` |

## Pay ID System

| Property | Value |
|----------|-------|
| Format | `handle@zbx` |
| pay_id | GLOBALLY UNIQUE (like UPI ID) |
| display_name | NOT unique (many "Rahul Kumar" can exist) |
| Per address | One Pay ID per wallet |
| Transfer | `zbx.transfer_to_pay_id("rahul@zbx", coin)` |

## Founder Admin Rules

| Can Do | Cannot Do |
|--------|-----------|
| Add new features via protocol upgrade | Change max supply (150M) |
| Update admin address | Change burn cap (75M) |
| Register new on-chain modules | Change max validators (41) |
| Update non-core params | Change address format (20 bytes) |
| | Change gas split (72/18/10) |
| | Enable manual liquidity in AMM |

MultiSig: **4/6 threshold** (6 signers, need 4 to approve)

---

*Zebvix Technologies Pvt Ltd — India*  
*Chain: zebvix-mainnet-1 | Token: ZBX | Version: 1.0.0*
